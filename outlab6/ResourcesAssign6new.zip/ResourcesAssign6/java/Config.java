
/**
 * Edit to provide your database credentials
 */
public class Config {
	public static final String url = "jdbc:postgresql://localhost:5432/whatasap";
	public static final String user = "testing1";
	public static final String password = "testing1";
}
