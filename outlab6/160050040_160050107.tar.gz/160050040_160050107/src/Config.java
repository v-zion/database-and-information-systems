
/**
 * Edit to provide your database credentials
 */
public class Config {
	public static final String url = "jdbc:postgresql://localhost:5400/postgres";
	public static final String user = "animesh";
	public static final String password = "";
}
